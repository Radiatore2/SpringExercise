package com.example.Ex1UnitTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1UnitTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex1UnitTestApplication.class, args);
	}

}
