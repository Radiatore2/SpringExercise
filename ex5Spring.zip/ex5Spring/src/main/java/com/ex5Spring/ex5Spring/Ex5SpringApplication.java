package com.ex5Spring.ex5Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex5SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex5SpringApplication.class, args);
	}

}
