package com.ex5Spring.ex5Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex3SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
